# OPTIM LeadFlow: Netlify + backend

Netlify hosts only the website (netlify-site). The real-time server (backend) must run on a host that keeps Node.js running.

## 1. Deploy the backend first (Render, Railway, Fly.io or a VPS)
- Upload the `backend` folder (or push it to GitHub).
- Build command: `npm install`   Start command: `npm start`
- Environment variables:
  - `ADMIN_PASSWORD` = your strong admin password (used on first start)
  - `ALLOWED_ORIGIN` = your Netlify address, e.g. `https://your-site.netlify.app` (add after step 2)
  - `TRUST_PROXY` = 1
  - `DATA_DIR` = path of a persistent disk (e.g. `/var/data`)
- IMPORTANT: attach a persistent disk/volume. Without one, data is erased on every restart or redeploy (free Render plans have no disk).
- Copy the backend's public URL, e.g. `https://leadflow-api.onrender.com`.

## 2. Deploy the website on Netlify
- Open `netlify-site/config.js` and replace `https://YOUR-BACKEND.onrender.com` with your backend URL (no trailing slash).
- Netlify -> Add new site -> Deploy manually -> drag the `netlify-site` folder in.
- Copy your Netlify address into `ALLOWED_ORIGIN` on the backend and redeploy it.

## 3. Open the Netlify address and sign in as `admin`.
